# Python-Hakagure-TextOnly
the plain 'ole Python version - the first one I did
