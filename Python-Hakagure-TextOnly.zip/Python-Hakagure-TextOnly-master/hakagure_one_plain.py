# Ben Woodfield - Random Line Grabber
# Used for Hakagure Python 1

# This grabs radnom lines of text from a txt file
# This method should work on larger files
# So the other ones worled by picking a random from
# the length of each line - so short lines were left out

# So far it only has 10 verses added to the text file
import random

def random_line():
    line_num = 0
    selected_line = ''
    with open('hakagure_words.txt') as f:
        while 1:
            line = f.readline()
            if not line: break
            line_num += 1
            if random.uniform(0, line_num) < 1:
                selected_line = line
    return selected_line.strip()

def restart_program():
        while True:
            restart = input("\n\n\n\nDo you want to see another verse? \nType '1' for Yes and 2 for No \n>>> ")
            if restart == 1:
                print random_line()
            else:
                print "Have a good Day"
                break


print random_line()
restart_program()
