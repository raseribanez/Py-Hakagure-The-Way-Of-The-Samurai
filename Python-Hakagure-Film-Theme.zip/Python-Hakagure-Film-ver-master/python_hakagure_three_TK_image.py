# Ben Woodfield
# Hakagure - The Way Of The Samurai
# Displays a random verse of text fom the Book - pulled from a txt file
# The Text File is saved in the same dir as this script for convenience
#
# I got the inspiration for this from the film "Ghost Dog"
# I am not gaining from this in any way it is just a personal project
# No quotes or verses are changed in any way - they are as they appear in the book
#
#
# Original Book: Hakagure
# Author: Yamamoto Tsunetomo
# Credits: GUI quote was the introduction to the actual Book
# Heres some info from the Book:
#
#
# Andrew R.Port
# Massachusetts Institute of Technology Department of Urban Studies & Planning
# Email: port@mit.edu Web
#!usr/bin/env/python

import random
import Tkinter as Tk

root = Tk.Tk()

def random_line():
    line_num = 0
    selected_line = ''
    with open('hakagure_words.txt') as f:
        while 1:
            line = f.readline()
            if not line: break
            line_num += 1
            if random.uniform(0, line_num) < 1:
                selected_line = line
                
    return selected_line.strip()

def print_a_verse():
    print random_line()
    print "\n"

background_image=Tk.PhotoImage(file="ghost.gif")#(file="samurai.gif")
background_label = Tk.Label(root, image=background_image)
background_label.place(x=0, y=0, relwidth=1, relheight=1)
root.wm_geometry("389x377+20+40")
root.title('Python - Hakagure')
playButton = Tk.Button(root, bg='Black', fg='Red', text='Next Verse', font='freesansbold,22', command=print_a_verse)
playButton.pack()

#playButton = Tk.Button(root, text='Play', command=root.destroy)
#playButton.pack()



root.mainloop()

