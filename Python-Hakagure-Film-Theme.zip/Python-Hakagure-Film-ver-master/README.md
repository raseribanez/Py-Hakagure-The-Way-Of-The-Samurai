# Python-Hakagure-Film-ver
The third version - using the image from the film

Verses from the book:


Hakagure


The Book Of The Samurai



