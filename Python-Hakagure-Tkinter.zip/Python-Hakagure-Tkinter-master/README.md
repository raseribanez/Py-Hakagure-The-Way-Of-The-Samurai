# Python-Hakagure-Tkinter
a second version - with an nice Japanese themed image
