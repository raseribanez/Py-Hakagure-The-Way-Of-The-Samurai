# Ben Woodfield
# Hakagure - The Way Of The Samurai
# Displays a random verse of text fom the Book - pulled from a txt file
# The Text File is saved in the same dir as this script for convenience
#
# I got the inspiration for this from the film "Ghost Dog"
# I am not gaining from this in any way it is just a personal project
# No quotes or verses are changed in any way - they are as they appear in the book
#
#
# Original Book: Hakagure
# Author: Yamamoto Tsunetomo
# Credits: GUI quote was the introduction to the actual Book
# Heres some info from the Book:
#
#
# Andrew R.Port
# Massachusetts Institute of Technology Department of Urban Studies & Planning
# Email: port@mit.edu Web


import random
import Tkinter as tk
from Tkinter import *

class MainApplication(tk.Frame):
    def __init__(self, parent, *args, **kwargs):
        tk.Frame.__init__(self, parent, *args, **kwargs)
        self.parent = parent

        def random_line():
            line_num = 0
            selected_line = ''
            with open('hakagure_words.txt') as f:
                while 1:
                    line = f.readline()
                    if not line: break
                    line_num += 1
                    if random.uniform(0, line_num) < 1:
                        selected_line = line
                        
            return selected_line.strip()

        def print_a_verse():
            print random_line()
            print "\n"

        btn_result = Button(self, fg='Red', text='New Verse', bg='Black', font='freesansbold, 16', command=print_a_verse) #textvariable=cvt_to, font='freesansbold, 16', fg='Blue')
        btn_result.pack(fill=X,side=TOP)#fill=BOTH, expand=1)

        lbl_one = Label(self, bg='DarkGrey', fg='White',  text='Hakagure', font='freesansbold, 22')
        lbl_one.pack(fill=BOTH, expand=1)

        lbl_thr = Label(self, bg='DarkGrey', fg='White', text='The Book of the Samurai \nYamamoto Tsunemoto', font='freesansbold, 18')
        lbl_thr.pack(fill=BOTH, expand=1)

        lbl_two = Label(self, bg='DarkGrey', fg='Grey', text='"Although the Hagakure was written centuries ago \nFor a breed of warriors that no longer exist, \nThe philosophies and wisdom within are still practical \nEven in our modern times."', font='freesans, 16')
        lbl_two.pack(fill=BOTH, expand=1)


if __name__ == "__main__":
    root = tk.Tk()
    root.minsize(400,400)
    #root.configure(bg='Black')
    root.title('Hakagure Python')
    MainApplication(root).pack(side="top", fill="both", expand=True)
    root.mainloop()
